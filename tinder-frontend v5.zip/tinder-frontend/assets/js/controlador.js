var usuarios = [];
var usuarioAuthenticate = null;
var usuariosInteres = [];
var perfilActual = -1;

const OPCION_USUARIOS = 1;
const OPCION_PERFILES = 2;
const OPCION_MATCHES = 3;
const OPCION_CREAR = 4;
const OPCION_ELIMINAR = 5;

const seleccionarOpcion = (opcion) => {
  switch (opcion) {
      case OPCION_USUARIOS:
        usuarioAuthenticate = null;
        console.log('Visualizar usuarios');
        document.getElementById('opcion-usuario').classList.add('active');
        document.getElementById('opcion-perfiles').classList.remove('flama-activa');
        document.getElementById('opcion-matches').classList.remove('estrella-activa');
        document.getElementById('bandeja-usuarios').style.display = "block";
        document.getElementById('informacion-perfiles').style.display = "none";
        document.getElementById('informacion-matches').style.display = "none";
        document.getElementById('informacion-crear-usuario').style.display = "none";
        obtenerUsuarios();

        document.getElementById('opcion-crear-usuario').style.display = "block";
        document.getElementById('opcion-eliminar-usuario').style.display = "none";

        break;
      case OPCION_PERFILES:
        if(usuarioAuthenticate != null)
        {
          console.log('Visualizar perfiles');
          document.getElementById('opcion-usuario').classList.remove('active');
          document.getElementById('opcion-perfiles').classList.add('flama-activa');
          document.getElementById('opcion-matches').classList.remove('estrella-activa');
          document.getElementById('opcion-activa').style.transform = 'translateX(0)';
          document.getElementById('bandeja-usuarios').style.display = "none";
          document.getElementById('informacion-perfiles').style.display = "block";
          document.getElementById('informacion-matches').style.display = "none";
          document.getElementById('informacion-crear-usuario').style.display = "none";
        }

        renderizarPerfil(usuarioAuthenticate);
        //document.getElementById('btn-perfil-siguiente').onclick();
        break;
      case OPCION_MATCHES:
        if(usuarioAuthenticate != null)
        {
          console.log('Visualizar matches');
          document.getElementById('opcion-usuario').classList.remove('active');
          document.getElementById('opcion-perfiles').classList.remove('flama-activa');
          document.getElementById('opcion-matches').classList.add('estrella-activa');
          document.getElementById('opcion-activa').style.transform = 'translateX(107%)';
          document.getElementById('bandeja-usuarios').style.display = "none";
          document.getElementById('informacion-perfiles').style.display = "none";
          document.getElementById('informacion-matches').style.display = "block";
          document.getElementById('informacion-crear-usuario').style.display = "none";

          renderizarMatches(usuarioAuthenticate.id);
        }
        break;
      case OPCION_CREAR:
        usuarioAuthenticate = null;
        document.getElementById('bandeja-usuarios').style.display = "none";
        document.getElementById('informacion-perfiles').style.display = "none";
        document.getElementById('informacion-matches').style.display = "none";
        document.getElementById('informacion-crear-usuario').style.display = "block";

        document.getElementById('opcion-crear-usuario').style.display = "none";
        document.getElementById('opcion-eliminar-usuario').style.display = "none";

        crearUsuario();
        break;
      case OPCION_ELIMINAR:
        if(usuarioAuthenticate != null)
        {
          eliminarUsuario(usuarioAuthenticate.id);
          seleccionarOpcion(OPCION_USUARIOS);
        }
        break;
      default:
        break;
  }
}

const obtenerUsuarios = () => {
  usuarios = [];

    fetch('http://localhost:3000/users', {
      method: 'GET',
      headers: {
        "Content-Type": "application/json", //MIME Type
      }
    })
    .then((respuesta) => respuesta.json())
    .then((respuesta) => {
      console.log(respuesta);
      usuarios = respuesta;
      renderizarUsuarios();
    }); 
  }
  obtenerUsuarios();

const renderizarUsuarios = () => {
    document.getElementById('usuarios').innerHTML = '';
    usuarios.forEach(usuario => {
      document.getElementById('usuarios').innerHTML +=
        `<div class="contenedor-usuario" onclick="obtenerUserAuthenticate(${usuario.id})">
          <img class="imagen-usuario" src="assets/Imagenes/${usuario.imagenPerfil}">
          <div class="text-username">
            ${usuario.nombre}
          </div>
        </div>`;
    });
}

const obtenerUserAuthenticate = (idUsuario) => {

  document.getElementById('opcion-crear-usuario').style.display = "none";
  document.getElementById('opcion-eliminar-usuario').style.display = "block";

  fetch('http://localhost:3000/users/'+idUsuario, {
    method: 'GET',
    headers: {
      "Content-Type": "application/json",
    }
  })
  .then((respuesta) => respuesta.json())
  .then((respuesta) => {
    usuarioAuthenticate = respuesta;
    console.log(usuarioAuthenticate);

    if(usuarioAuthenticate.verificado)
    {
      document.getElementById("opcion-usuario").style.color = "rgb(0, 150, 255)";
    }
    else
    {
      document.getElementById("opcion-usuario").style.color = "gray";
    }

    obtenerUsuariosInteres();
    //renderizarPerfil(usuarioAuthenticate);
    seleccionarOpcion(2);
    //renderizarMatches(usuarioAuthenticate.id);
  });
}

const obtenerUsuariosInteres = () => {

  usuariosInteres = [];
  perfilActual = 0;

  for(var i in usuarios)
    {
      if (usuarioAuthenticate.generoInteres.includes(usuarios[i].genero))
      {
        fetch('http://localhost:3000/users/'+usuarios[i].id, {
          method: 'GET',
          headers: {
            "Content-Type": "application/json",
          }
        })
          .then((respuesta) => respuesta.json())
          .then((respuesta) => {
            console.log(respuesta);
            if(respuesta.id != usuarioAuthenticate.id)
            {
              usuariosInteres.push(respuesta);
            }
          });
      }
    }
    console.log(usuariosInteres)
}

const renderizarPerfil = (usuario) => {
  
  var listaIntereses = "";
  for(var i in usuario.intereses)
  {
    listaIntereses += `<div class="item-gusto">${usuario.intereses[i]}</div>`;
  }

  document.getElementById('detalle-perfil').innerHTML = 
    `<div class="perfil" style="background-image: url(assets/Imagenes/${usuario.imagenPortada});">
      <div class="informacion-perfil">
        <div>
          <span class="nombre">${usuario.nombre}</span>
          <span class="edad">${usuario.edad}</span>  
          ${usuario.verificado ? '<span class="icono-check"><i class="fa-solid fa-circle-check"></i></span>' : ''}
        </div>
        <div>
          <span><i class="fa-solid fa-briefcase"></i></span>
          <span>${usuario.ocupacion}</span>
        </div>
        <div>
          <span><i class="fa-solid fa-location-dot"></i></span>
          <span>${usuario.ciudad}</span>
        </div>
        <div class="contenedor-gustos">` + 
        listaIntereses + 
        `</div>
      </div>
    </div>`;
}

const perfilSiguiente = () => {

  if (perfilActual >= (usuariosInteres.length-1) || perfilActual == -1)
  {
    perfilActual = 0;  
  } 
  else
  {
    perfilActual++;
  }

  console.log('Perfil a mostrar', usuariosInteres[perfilActual]);
  renderizarPerfil(usuariosInteres[perfilActual]);

  if(usuariosInteres[perfilActual].likes.includes(usuarioAuthenticate.id))
  {
    document.getElementById("boton-corazon").style.color = "red";
  }
  else
  {
    document.getElementById("boton-corazon").style.color = "#3ee9bd";
  }
}

const perfilAnterior = () => {

  if (perfilActual <= 0 )
  {
    perfilActual = usuariosInteres.length - 1;
  }
  else
  {
    perfilActual--;
  }

  console.log('Perfil a mostrar', usuariosInteres[perfilActual]);
  renderizarPerfil(usuariosInteres[perfilActual]);

  if(usuariosInteres[perfilActual].likes.includes(usuarioAuthenticate.id))
  {
    document.getElementById("boton-corazon").style.color = "red";
  }
  else
  {
    document.getElementById("boton-corazon").style.color = "#3ee9bd";
  }
}

const like = () => {

  var perfil = usuariosInteres[perfilActual];

  if(!perfil.likes.includes(usuarioAuthenticate.id))
  {
    document.getElementById("boton-corazon").style.color = "red";

    perfil.likes.push(usuarioAuthenticate.id);
    console.log("Usuario a Modificar: ");
    console.log(perfil);

    // Registrar Like
    actualizarUsuario(perfil.id, perfil);

    // Comprobar si hay match y establecerlo
    if(usuarioAuthenticate.likes.includes(perfil.id) && perfil.likes.includes(usuarioAuthenticate.id))
    {
      perfil.matches.push(usuarioAuthenticate.id);
      usuarioAuthenticate.matches.push(perfil.id);

      actualizarUsuario(perfil.id, perfil);
      actualizarUsuario(usuarioAuthenticate.id, usuarioAuthenticate);

      renderizarMatches(usuarioAuthenticate.id);
    }
  }
}

const renderizarMatches = (id) => {
  
  document.getElementById('matches-cards').innerHTML = ``;

  var usuariosMatches = [];
  fetch('http://localhost:3000/users/'+id+'/matches', {
      method: 'GET',
      headers: {
        "Content-Type": "application/json", //MIME Type
      }
    })
    .then((respuesta) => respuesta.json())
    .then((respuesta) => {
      console.log("Matches");
      usuariosMatches = respuesta;
      console.log(usuariosMatches);
    for(var i in usuariosMatches)
    {
      console.log(i);
    document.getElementById('matches-cards').innerHTML += 
    `<div class="tarjeta-usuario">
    <div class="imagen">
      <img class='' src="assets/Imagenes/${usuariosMatches[i].imagenPerfil}">
    </div>
    <div class="detalle">
      <div>
        <span class="nombre">${usuariosMatches[i].nombre}</span>
        <span class="edad">${usuariosMatches[i].edad}</span>  
        ${usuariosMatches[i].verificado ? '<span class="icono-check"><i class="fa-solid fa-circle-check"></i></span>' : ''}
      </div>
      <div>
        <span class="text-g"><i class="fa-solid fa-briefcase"></i></span>
        <span>${usuariosMatches[i].ocupacion}</span>
      </div>
      <div>
        <span class="text-g"><i class="fa-solid fa-location-dot"></i></span>
        <span>${usuariosMatches[i].ciudad}</span>
      </div>
    </div>
    </div>`;
    }
    }); 
}

const crearUsuario = () => {
}

const crearUsuarioPrueba = () => {

  fetch('http://localhost:3000/users', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        "id": 19,
        "nombre": "Zuko",
        "genero": "M",
        "verificado": true,
        "edad": 30,
        "imagenPerfil": "profile-pics/zuko.jpg",
        "imagenPortada": "cover-pics/zuko.jpg",
        "ocupacion": "Maestro de Fuego",
        "ciudad": "Kanar",
        "intereses": ["Destruir", "Comer", "Fuego"],
        "matches": [7, 4],
        "likes": [7, 4],
        "generoInteres": ["F"]
    })
})
.then( (response) => { 
  //do something awesome that makes the world a better place
});

}

const eliminarUsuario = (id) => {

  fetch('http://localhost:3000/users/'+id,{
    method:'DELETE'
  }).then(response=>{
    return response.text()
  }).then(data=> 
    // this is the data we get after putting our data,
    console.log(data)
  );
}

function actualizarUsuario(id, usuarioDatos)
{
  fetch('http://localhost:3000/users/'+id,{
    method:'PUT',
    headers:{
    'Content-Type':'application/json'
    },
    body:JSON.stringify(usuarioDatos)
  }).then(response=>{
    return response.json()
    }).then(data=> 
    // this is the data we get after putting our data,
    console.log(data)
    );
}

function obtenerUsuario(id)
{
  var resultado; 

  fetch('http://localhost:3000/users/'+id, {
          method: 'GET',
          headers: {
            "Content-Type": "application/json",
          }
        })
          .then((respuesta) => respuesta.json())
          .then((respuesta) => {
            resultado = respuesta;
          });
          
  return resultado;
}
